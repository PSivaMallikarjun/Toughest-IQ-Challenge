const questions = [
    {
        question: "Can you cover a 63-square chessboard with 31 dominoes if one square is missing?",
        options: ["Yes", "No", "Only if the missing square is at the center", "Depends on the missing square"],
        correct: "No"
    },
    {
        question: "How can you determine which switch controls which light bulb?",
        options: ["By turning one switch on, waiting, then checking heat", "By randomly checking", "By flipping all switches", "It's impossible"],
        correct: "By turning one switch on, waiting, then checking heat"
    },
    {
        question: "What is the probability that both children are boys if at least one is a boy?",
        options: ["1/2", "1/3", "1/4", "2/3"],
        correct: "1/3"
    },
    {
        question: "How can you measure 45 minutes using two ropes?",
        options: ["Burn one rope at both ends, then the other", "Burn both ropes at one end", "Cut and measure", "Use a stopwatch"],
        correct: "Burn one rope at both ends, then the other"
    },
    {
        question: "What happens if you ask a liar and a truth-teller about the correct door?",
        options: ["You always get the wrong door", "You always get the right door", "You need more information", "They will fight"],
        correct: "You always get the wrong door"
    },
    {
        question: "Can an infinite hotel accommodate one more guest if full?",
        options: ["Yes, by shifting guests", "No", "Only if someone leaves", "Depends on the manager"],
        correct: "Yes, by shifting guests"
    },
    {
        question: "What color are the hats in the wise men's puzzle?",
        options: ["All Red", "All Blue", "Mixed", "Cannot be determined"],
        correct: "All Red"
    },
    {
        question: "How can you find a counterfeit coin among 12 in 3 weighings?",
        options: ["Divide into 3 groups and weigh strategically", "Use a magnet", "Check weight manually", "Impossible"],
        correct: "Divide into 3 groups and weigh strategically"
    },
    {
        question: "Where is the missing dollar in the hotel bill riddle?",
        options: ["No dollar is missing, it's a math trick", "It's in the bellboy's pocket", "They were overcharged", "It’s in the register"],
        correct: "No dollar is missing, it's a math trick"
    }
];

let currentQuestion = 0;
let score = 0;
let timeLeft = 300; // 5 minutes
let timer = setInterval(() => {
    timeLeft--;
    document.getElementById("time").textContent = timeLeft;
    if (timeLeft === 0) {
        endQuiz();
    }
}, 1000);

function loadQuestion() {
    if (currentQuestion >= questions.length) {
        endQuiz();
        return;
    }
    
    document.getElementById("question-box").innerHTML = `<h2>${questions[currentQuestion].question}</h2>`;
    let optionsHTML = "";
    
    questions[currentQuestion].options.forEach(option => {
        optionsHTML += `<button onclick="checkAnswer('${option}')">${option}</button><br>`;
    });
    
    document.getElementById("options-box").innerHTML = optionsHTML;
}

function checkAnswer(answer) {
    if (answer === questions[currentQuestion].correct) {
        score++;
    }
    currentQuestion++;
    loadQuestion();
}

function endQuiz() {
    clearInterval(timer);
    document.getElementById("quiz-container").innerHTML = `<h2>Quiz Over!</h2><p>Your Score: ${score} / ${questions.length}</p>`;
}

loadQuestion();
